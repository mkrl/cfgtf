Put the "cfg" folder in your  "Steam/steamapps/common/Team Fortress 2/tf" folder.


The autoexec.cfg is the competitive/performance config. It contains a couple scripts at the top, and some things for you to bind to keys. Make sure you configure the multicore rendering section to fit your CPU core #, and toggle these values to "0" one by one to troubleshoot crashes.

To enable/disable individual scripts, go into the class cfg and remove/add "//" before "exec [config]".

All classes but spy use the "default.cfg". Open this one up and configure it to your preference.

The null-movement script is enbabled by default. Turn it off by adding "//" in front of "exec movement" in the appropriate class .cfg's.


For script questions, please go here--I do not provide troubleshooting, sorry:

http://forums.steampowered.com/forums/showthread.php?t=1591457http://forums.steampowered.com/forums/showthread.php?t=1591457
http://www.reddit.com/r/tf2scripts

If you would like to use Comangila's FPS Config, rename the .cfg to "autoexec.cfg" and place it in your "cfg" folder.