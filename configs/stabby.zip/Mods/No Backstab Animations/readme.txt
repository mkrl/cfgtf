The backstab animation (pushing knife downwards) is not shown in servers which have random critical hits disabled (this is why you do not see stabby's game use this animation very much).
This animation can be removed by using custom animations. At the download link (above) you will be able to download the three possible animation overrides for the backstab. They each are a different type of movement with the knife (all of which can be seen when you +attack without being in backstab range in game).
Note, you can only use one of the three at any given time. You cannot tell it to randomly pick one (this is how it works in nocrit servers).
Installation Instructions:
Download the zipped file above
extract its contents to your desktop
Choose one of the folders labeled "No-Crit Backstab Animations (INSERT TYPE HERE)"
copy/paste that folder into your tf/custom folder.

http://forums.steampowered.com/forums/showthread.php?p=35171852