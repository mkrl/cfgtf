Updated: 4-12-2012

My config. The FPS config (located in autoexec.cfg alongside some personalized settings) is Chris' DX8 Maxframes config.