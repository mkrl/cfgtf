Place the custom folder in your tf folder.
Place the quake live crosshair files in tf\materials\vgui\replay\thumbnails

I have only set quake crosshairs for soldier and scout default weapons, as that is all I usually play.