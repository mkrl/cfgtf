AdBlock & Protection for TF2
============================

Hello, since recently an exploit was discovered to execute arbitrary commands on clients (fixed in yesterday's update) I decided to see what could be done about this with purely cfg scripts to protect against this.

_Features:_

*	Protection against an invasive server anti-cheat (taking & uploading screenshots behind your back). Now useless because of the update.
*	AdBlocks against pinion motd adverts (Stops the 'You may close the MOTD in 5 seconds'!).
*	Prevents servers from playing sounds on your client.
*	There are some commands the server is allowed to execute, I don't see why the server needs access & blocked it.

_Download:_

Available [here](https://github.com/CasualX/SourceProtect).

_Install instructions:_

Click the 'ZIP' button in the description. Extract protect.cfg to your tf\cfg folder. Add 'exec protect.cfg' to your autoexec. 
