Eniere's Improved default HUD ver. 3.7.1
January 31, 2017

This is not a custom HUD in its usual meaning, but some fixes for standard Team Fortress 2 UI, adding HP numbers on target IDs, reworked Medic UI, popular custom crosshairs, etc.

Gallery: http://imgur.com/a/l9qai
How-to and changelog: http://eniere.github.io
Donate: http://huds.tf/forum/showthread.php?tid=276

Discussions:
(en) http://teamfortress.tv/thread/16751/improved-default-hud
(en) http://etf2l.org/forum/customise/topic-28385
(ru) https://pixling.ru/blog/1037.html

Reminder: Install all the fonts (idhud-master\resource\fonts\) in to the OS before using.
Please, use Notepad++ (http://notepad-plus-plus.org/) to preview or edit files.