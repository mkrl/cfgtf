Some customization presets can be applied to the in-game aspect of the HUD.

Instuctions for this are found at the top of this file:

resource/ClientScheme.res