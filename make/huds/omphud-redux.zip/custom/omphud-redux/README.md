#omphud-redux

classic omphud, updated to 2016 with all sorts of new goodies thrown in

#####Version: 1.2
#####Released: August 15, 2016

visit hudlayout.res to install custom crosshairs

